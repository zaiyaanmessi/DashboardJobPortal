import Layout from "@/components/layout/Layout"

export default function Home() {
    return (
        <>
            <Layout breadcrumbTitle="My Profile" breadcrumbActive="My Profile">

            </Layout>
        </>
    )
}